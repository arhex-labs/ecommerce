<?php

    if(!file_exists('core/config.php')){
        header('LOCATION: setup.php');
    }
    
    

?>