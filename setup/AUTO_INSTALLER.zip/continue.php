<?php
    require "admin/core/config.php";
    require "admin/core/MyDbHandler.php";

    $db = new MyDbHandler(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $error = "";

    if(isset($_POST['add_user'])){
        $username = $_POST['username'];
        $password1 = $_POST['password1'];
        $password2 = $_POST['password2'];
        if($password1 == $password2){
            $password = md5($password1);
            $data = array(
                'users_username'=>$username, 
                'users_password'=>$password
            );
            $db->insert('users', $data);
            $data = array(
                'page_info_title'=>$_POST['title']
            );
            $db->insert('page_info', $data);
            header('LOCATION: index.php?delete_setup=delete');
        } else {
            $error = "WRONG PASSWORD";
        }
    }



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

        @import url('https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap');

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body{
            position: relative;
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('https://raw.githubusercontent.com/arhex-labs/ecommerce/main/bbb.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }

        .container{
            position: relative;
            width: 80%;
            background-color: rgba(255, 255, 255, 0.7);
            min-height: 100px;
            max-height: auto;
            padding: 40px;
            border-radius: 20px;
            border: 1px solid #aaa;
        }
        h2{
            line-height: 2;
            font-size: 1.6rem;
        }
        .container input{
            display: inline-block;
            width: 48.5%;
            padding: 12px 14px;
            margin: 1px;
            margin-bottom: 10px;
            border: 1px solid #aaa;
        }
        .container input[type="submit"]{
            background-size: 200% auto;
            background-image: linear-gradient(to right, #7474bf 0%, #348AC7 51%, #7474bf 100%);
            text-transform: uppercase;
            transition: 0.5s;
            color: #fff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
            transition: all 0.3s cubic-bezier(.25, .8, .25, 1);
            cursor: pointer;
        }
        .container input[type="submit"]{
            background-position: right center;
        }
        fieldset{
            padding: 20px;
        }
        .container p{
            text-transform: uppercase;
            color: red;
            line-height: 2;
        }
        @media screen and (max-width: 940px){
            .container{
                text-align: center;
            }
            .container input{
                width: 100%;
                margin: 0;
                margin-bottom: 10px;
            }
        }
    </style>
    <title>ARHEX E-COMMERCE SETUP</title>
</head>
<body>
    <div class="container">
        <fieldset>
            <legend><h2>ARHEX SETUP</h2></legend>
            <form action="" method="post">
                <input type="text" name="title" id="title" placeholder="Website Title" required>
                <input type="text" name="username" id="username" placeholder="Admin Username" required>
                <input type="text" name="password1" id="password1" placeholder="Password" required>
                <input type="text" name="password2" id="password2" placeholder="Confirm Password" required>
                <input type="submit" name="add_user" value="Finish Setup">
            </form>
            <p><?php if(!empty($error)){ echo '* '.$error; } ?></p>
        </fieldset>
    </div>
</body>
</html>